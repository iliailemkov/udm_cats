package com.beardie.udm_cats.local.models

data class User(
  val id: Long,
  val login: String,
  val name: String,
  val password: String,
  val avatar: String,
  val gender: String,
  val dateBirthday: Long,
  val about: String
)