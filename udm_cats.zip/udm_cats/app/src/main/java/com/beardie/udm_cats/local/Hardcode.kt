package com.beardie.udm_cats.local

import com.beardie.udm_cats.local.models.Event
import java.util.*

class Hardcode {
  companion object {
    val events = List(4) {
      Event(1, 1, 1, "Бегаем", Date(), Date(), 56.87273200, 53.22717200, "На самом деле посидим попьем пивка")
      Event(2, 1, 1, "Бегаем", Date(), Date(), 56.87273200, 53.22717200, "На самом деле посидим попьем пивка")
      Event(3, 1, 1, "Бегаем", Date(), Date(), 56.87273200, 53.22717200, "На самом деле посидим попьем пивка")
      Event(4, 1, 1, "Бегаем", Date(), Date(), 56.87273200, 53.22717200, "На самом деле посидим попьем пивка")
    }
  }
}