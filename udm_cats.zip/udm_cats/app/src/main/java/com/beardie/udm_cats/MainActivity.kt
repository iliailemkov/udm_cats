package com.beardie.udm_cats

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.beardie.udm_cats.navigation.INavigation
import com.beardie.udm_cats.ui.map.MapFragment

class MainActivity : AppCompatActivity(), INavigation {

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    setContentView(R.layout.activity_main)
    supportActionBar?.hide()
    naviagteTo(MapFragment.newInstance())
  }

  override fun naviagteTo(fragment: Fragment) {
    supportFragmentManager.beginTransaction().replace(R.id.main_container, fragment).addToBackStack("navigateTo")
      .commit()
  }


}
