package com.beardie.udm_cats.navigation

import androidx.fragment.app.Fragment

interface INavigation {
  fun naviagteTo(fragment: Fragment)
}