package com.beardie.udm_cats.ui.event

import androidx.core.os.bundleOf
import com.google.android.material.bottomsheet.BottomSheetDialogFragment

class EventFragment : BottomSheetDialogFragment() {

  val EVENT_ID = "account_id"

  companion object {
    fun newInstance(eventId : Long) = EventFragment().apply {
      arguments = bundleOf(EVENT_ID to eventId)
    }
  }

  var eventId: Long? = null

}