package com.beardie.udm_cats.ui.map

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.LocationManager
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.app.ActivityCompat
import androidx.fragment.app.Fragment
import com.beardie.udm_cats.BaseApplication
import com.beardie.udm_cats.R
import com.beardie.udm_cats.local.Hardcode
import com.beardie.udm_cats.local.models.Event
import com.beardie.udm_cats.navigation.INavigation
import com.beardie.udm_cats.ui.event.EventFragment
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.MapView
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import java.util.*


class MapFragment : Fragment(), GoogleMap.OnMapLoadedCallback, OnMapReadyCallback,
  GoogleMap.OnMyLocationButtonClickListener {

  private lateinit var googleMap: GoogleMap
  private lateinit var mapView: MapView
  private lateinit var locationManager: LocationManager
  /**
   * Координаты Ижевска
   */
  private val startPosition = LatLng(56.87273200, 53.22717200)
  private val startZoom = 13.0f
  private var mapMarkerToEvent: TreeMap<String, Long> = TreeMap()

  companion object {
    fun newInstance() = MapFragment()
  }

  private fun checkGeolocationEnabled(): Boolean {
    if (activity == null)
      return false
    if (ActivityCompat.checkSelfPermission(
        activity!!,
        Manifest.permission.ACCESS_FINE_LOCATION
      ) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
        activity!!,
        Manifest.permission.ACCESS_COARSE_LOCATION
      ) != PackageManager.PERMISSION_GRANTED
    )
      return false
    return true
  }

  @SuppressLint("MissingPermission")
  private fun initMap(map: GoogleMap) {
    googleMap = map
    if (checkGeolocationEnabled())
      googleMap.isMyLocationEnabled = true
    googleMap.uiSettings.isMyLocationButtonEnabled = true
    googleMap.uiSettings.isZoomControlsEnabled = true
    Hardcode.events.forEach {
      val marker = googleMap.addMarker(initMarkersByEvent(it))
      mapMarkerToEvent[marker.id] = it.id
    }
    googleMap.setOnInfoWindowClickListener {
      (activity as INavigation).naviagteTo(
        EventFragment.newInstance(
          mapMarkerToEvent[it.id]!!
        )
      )
    }

    //googleMap.setOnMarkerClickListener(clusterManager)
    //
    /*clusterManager = ClusterManager<ShopClusterItem>(activity!!, mMap)
    clusterManager.setRenderer(ShopMarkerIcon(activity, mMap, clusterManager, activity!!.layoutInflater))
    clusterManager.setOnClusterItemClickListener(this)
    clusterManager.setOnClusterClickListener(this)
    clusterManager.setOnClusterItemInfoWindowClickListener(this)
    clusterManager.getMarkerCollection().setOnInfoWindowAdapter(shopInfoWindowAdapter)*/
    //
    /*mMap.setInfoWindowAdapter(clusterManager.getMarkerManager())
    mMap.setOnCameraIdleListener(clusterManager)
    mMap.setOnMarkerClickListener(clusterManager)
    mMap.setOnInfoWindowClickListener(clusterManager)
    mMap.setOnMyLocationButtonClickListener(this)*/
    googleMap.setOnMapLoadedCallback(this)
    googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(startPosition, startZoom))
  }

  private fun initMarkersByEvent(event: Event): MarkerOptions {
    val markerOptions = MarkerOptions()
    markerOptions.icon(BitmapDescriptorFactory.fromResource(R.drawable.ic_marker))
    markerOptions.position(LatLng(event.latitude, event.longitude))
    markerOptions.title(event.name)
    markerOptions.snippet(event.about)
    return markerOptions
  }

  override fun onActivityCreated(savedInstanceState: Bundle?) {
    super.onActivityCreated(savedInstanceState)
    locationManager =
      BaseApplication.getInstance().applicationContext.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    checkGeolocationEnabled()
  }

  override fun onCreateView(
    inflater: LayoutInflater, container: ViewGroup?,
    savedInstanceState: Bundle?
  ): View {
    val view = inflater.inflate(R.layout.map_fragment, container, false)
    mapView = view.findViewById(R.id.mv_map) as MapView
    mapView.onCreate(savedInstanceState)
    mapView.onResume()
    mapView.getMapAsync(this)
    return view
  }

  override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
    super.onViewCreated(view, savedInstanceState)
  }

  override fun onMapLoaded() {
  }

  override fun onMapReady(map: GoogleMap) {

    if (isAdded)
      initMap(map)
  }

  override fun onMyLocationButtonClick(): Boolean {
    return true
  }
}
