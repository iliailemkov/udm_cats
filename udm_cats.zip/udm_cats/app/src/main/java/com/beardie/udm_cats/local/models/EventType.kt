package com.beardie.udm_cats.local.models

data class EventType(
  val id: Long,
  val name: String
)