package com.beardie.udm_cats

import android.app.Application

class BaseApplication : Application() {

  companion object {
    private lateinit var instance: BaseApplication
    fun getInstance() = instance
  }

  override fun onCreate() {
    super.onCreate()
    instance = this
    Thread.setDefaultUncaughtExceptionHandler { paramThread, paramThrowable -> {} }
  }
}

