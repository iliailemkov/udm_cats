package com.beardie.udm_cats.local.models

import java.util.*

data class Event(
  val id: Long,
  val typeTypeId: Long,
  val userId: Long,
  val name: String,
  val dateStart: Date,
  val dateEnd: Date,
  val latitude: Double,
  val longitude: Double,
  val about: String
)